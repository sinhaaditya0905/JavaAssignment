package com.example.demo.entities;

import jakarta.persistence.Entity;
import lombok.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class Customer {
    String firstName;
    String lastName;
    String street;
    String address;
    String city;
    String state;
    String email;
    String phone;
}
