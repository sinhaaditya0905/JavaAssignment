package com.example.demo.services;

import com.example.demo.entities.Customer;
import com.example.demo.repositories.CustomerRepositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepositories customerRepositories;

    @Override
    public Customer createCustomer(Customer customer) {
        // Save the new customer to the database
        return customerRepositories.save(customer);
    }

    @Override
    public void deleteCustomer(int customerId) {
        // Delete the customer from the database
        customerRepositories.deleteById(customerId);
    }

    @Override
    public List<Customer> getAllCustomers() {
        // Retrieve all customers from the database
        return customerRepositories.findAll();
    }

    @Override
    public Customer getCustomerById(int customerId) {
        // Retrieve a customer by ID from the database
        Optional<Customer> optionalCustomer = customerRepositories.findById(customerId);
        return optionalCustomer.orElse(null); // Returns null if not found
    }

    @Override
    public void updateCustomer(int customerId, Customer customer) {
        // Check if the customer with the given ID exists
        Optional<Customer> optionalExistingCustomer = customerRepositories.findById(customerId);

        if (optionalExistingCustomer.isPresent()) {
            // Update the existing customer with the new data
            Customer existingCustomer = optionalExistingCustomer.get();
            existingCustomer.setFirstName(customer.getFirstName());
            existingCustomer.setLastName(customer.getLastName());
            existingCustomer.setStreet(customer.getStreet());
            existingCustomer.setAddress(customer.getAddress());
            existingCustomer.setCity(customer.getCity());
            existingCustomer.setState(customer.getState());
            existingCustomer.setEmail(customer.getEmail());
            existingCustomer.setPhone(customer.getPhone());

            // Save the updated customer to the database
            customerRepositories.save(existingCustomer);
        }
        // If the customer with the given ID does not exist, you can handle it as needed
    }
}
