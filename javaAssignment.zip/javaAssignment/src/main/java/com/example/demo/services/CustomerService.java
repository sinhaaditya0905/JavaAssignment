package com.example.demo.services;

import com.example.demo.entities.Customer;

import java.util.List;

public interface CustomerService {
    public Customer createCustomer(Customer customer);

    public void  deleteCustomer(int customerId);

    Object getAllCustomers();

    Customer getCustomerById(int customerId);

    void updateCustomer(int customerId, Customer customer);
}
