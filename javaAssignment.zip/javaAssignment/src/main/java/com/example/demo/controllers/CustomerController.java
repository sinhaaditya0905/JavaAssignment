package com.example.demo.controllers;

import com.example.demo.entities.Customer;
import com.example.demo.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    // Get all customers
    @GetMapping
    public String getCustomers(Model model) {
        model.addAttribute("customers", customerService.getAllCustomers());
        return "customerList";
    }

    // Get customer by ID
    @GetMapping("/{customerId}")
    public String getCustomerById(@PathVariable int customerId, Model model) {
        Customer customer = customerService.getCustomerById(customerId);

        if (customer != null) {
            model.addAttribute("customer", customer);
            return "customerDetails"; // Logical view name for displaying customer details
        } else {
            return "customerNotFound"; // Logical view name for customer not found
        }
    }

    // Other methods for adding, updating, and deleting customers...

    // Display the form for adding a new customer
    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("customer", new Customer());
        return "addCustomer";
    }

    // Process the form submission for adding a new customer
    @PostMapping("/add")
    public String addCustomer(@ModelAttribute("customer") Customer customer) {
        customerService.createCustomer(customer);
        return "redirect:/customers";
    }

    // Display the form for updating an existing customer
    @GetMapping("/update/{customerId}")
    public String showUpdateForm(@PathVariable int customerId, Model model) {
        Customer customer = customerService.getCustomerById(customerId);
        model.addAttribute("customer", customer);
        return "updateCustomer";
    }

    // Process the form submission for updating an existing customer
    @PostMapping("/update/{customerId}")
    public String updateCustomer(@PathVariable int customerId, @ModelAttribute("customer") Customer customer) {
        customerService.updateCustomer(customerId, customer);
        return "redirect:/customers";
    }

    // Delete a customer
    @GetMapping("/delete/{customerId}")
    public String deleteCustomer(@PathVariable int customerId) {
        customerService.deleteCustomer(customerId);
        return "redirect:/customers";
    }
}
